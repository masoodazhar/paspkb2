<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Models\About;

class HomeApisController extends Controller
{
    function get_speakersmessages(){
        $speakers = [];
        $speaker = DB::table('speakers_main')
        ->join('members_directories', 'members_directories.id','speakers_main.members_directories_id')  
        ->select('speakers_main.speakermessage','speakers_main.designation','members_directories.name','members_directories.image','members_directories.id')
        ->first();

        $deputyspeaker = DB::table('deputy_speakers_main')
        ->join('members_directories', 'members_directories.id','deputy_speakers_main.members_directories_id')  
        ->select('deputy_speakers_main.speakermessage','deputy_speakers_main.designation','members_directories.name','members_directories.image','members_directories.id')
        ->first();
        $speakers = [$speaker,$deputyspeaker];
        // dd($speakers);
        return response()->json($speakers);
    }

    public function get_sessionsorderoftheday() {
        $allmainSessions = DB::table('order_of_the_day_summary_of_proceedings')  
        ->join('sessions', 'sessions.id', '=', 'order_of_the_day_summary_of_proceedings.sessions_id')
        ->join('main_sessions', 'main_sessions.id', '=', 'sessions.main_sessions_id')
        ->join('assembly_tenures', 'assembly_tenures.id', '=', 'main_sessions.assembly_tenures_id')
        ->join('assemblies', 'assemblies.id', '=', 'assembly_tenures.assembly_id')
        ->select('main_sessions.*','assemblies.name')
        ->where('order_of_the_day_summary_of_proceedings.sittingstype', 'Order of the Day')
        ->orderBy('main_sessions.id')
        ->get();
        $spg = $allmainSessions->unique('sessionname');
        $allmainSessions = array_slice($spg->values()->all(),0,1000, true);

        $allRows = [];
        foreach($allmainSessions as $msession){            
            $sessions = DB::table('order_of_the_day_summary_of_proceedings as ord')
            ->join('sessions', 'sessions.id', '=', 'ord.sessions_id')
            ->select('sessions.*','ord.id as orderid','ord.sittingstype','ord.sittingsno','ord.sittingsdate','ord.type', 'ord.description')
            ->where('sessions.main_sessions_id', $msession->id)
            ->where('ord.sittingstype', 'Order of the Day')
            ->get();
            $sess = array(
                'sessionname'=>$msession->sessionname,
                'sessionid'=>$msession->id,
                'assemblyname'=>$msession->name,
                'listofsessions'=>$sessions
            );  
            array_push($allRows,$sess);
        }
        // dd($allRows);
        return response()->json($allRows);
    }

    public function get_sessionssummery() {
        $allmainSessions = DB::table('order_of_the_day_summary_of_proceedings')  
        ->join('sessions', 'sessions.id', '=', 'order_of_the_day_summary_of_proceedings.sessions_id')
        ->join('main_sessions', 'main_sessions.id', '=', 'sessions.main_sessions_id')
        ->join('assembly_tenures', 'assembly_tenures.id', '=', 'main_sessions.assembly_tenures_id')
        ->join('assemblies', 'assemblies.id', '=', 'assembly_tenures.assembly_id')
        ->select('main_sessions.*','assemblies.name')
        ->where('order_of_the_day_summary_of_proceedings.sittingstype', 'Summary of Proceedings')
        ->orderBy('main_sessions.id')
        ->get();
        $spg = $allmainSessions->unique('sessionname');
        $allmainSessions = array_slice($spg->values()->all(),0,1000, true);

        $allRows = [];
        foreach($allmainSessions as $msession){            
            $sessions = DB::table('order_of_the_day_summary_of_proceedings as ord')
            ->join('sessions', 'sessions.id', '=', 'ord.sessions_id')
            ->select('sessions.*','ord.id as orderid','ord.sittingstype','ord.sittingsno','ord.sittingsdate','ord.type', 'ord.description')
            ->where('sessions.main_sessions_id', $msession->id)
            ->where('ord.sittingstype', 'Summary of Proceedings')
            ->get();
            $sess = array(
                'sessionname'=>$msession->sessionname,
                'sessionid'=>$msession->id,
                'assemblyname'=>$msession->name,
                'listofsessions'=>$sessions
            );  
            array_push($allRows,$sess);
        }
        // dd($allRows);
        return response()->json($allRows);
    }

    public function get_sessionshouse() {
        $allmainSessions = DB::table('order_of_the_day_summary_of_proceedings')  
        ->join('sessions', 'sessions.id', '=', 'order_of_the_day_summary_of_proceedings.sessions_id')
        ->join('main_sessions', 'main_sessions.id', '=', 'sessions.main_sessions_id')
        ->join('assembly_tenures', 'assembly_tenures.id', '=', 'main_sessions.assembly_tenures_id')
        ->join('assemblies', 'assemblies.id', '=', 'assembly_tenures.assembly_id')
        ->select('main_sessions.*','assemblies.name')
        ->where('order_of_the_day_summary_of_proceedings.sittingstype', 'House Debates')
        ->orderBy('main_sessions.id')
        ->get();
        $spg = $allmainSessions->unique('sessionname');
        $allmainSessions = array_slice($spg->values()->all(),0,1000, true);

        $allRows = [];
        foreach($allmainSessions as $msession){            
            $sessions = DB::table('order_of_the_day_summary_of_proceedings as ord')
            ->join('sessions', 'sessions.id', '=', 'ord.sessions_id')
            ->select('sessions.*','ord.id as orderid','ord.sittingstype','ord.sittingsno','ord.sittingsdate','ord.type', 'ord.description')
            ->where('sessions.main_sessions_id', $msession->id)
            ->where('ord.sittingstype', 'House Debates')
            ->get();
            $sess = array(
                'sessionname'=>$msession->sessionname,
                'assemblyname'=>$msession->name,
                'sessionid'=>$msession->id,
                'listofsessions'=>$sessions
            );  
            array_push($allRows,$sess);
        }
        // dd($allRows);
        return response()->json($allRows);
    }

    public function get_sessionsresolution() {
        $allmainSessions = DB::table('resolutions_passeds')  
        ->join('sessions', 'sessions.id', '=', 'resolutions_passeds.sessions_id')
        ->join('main_sessions', 'main_sessions.id', '=', 'sessions.main_sessions_id')
        ->join('assembly_tenures', 'assembly_tenures.id', '=', 'main_sessions.assembly_tenures_id')
        ->join('assemblies', 'assemblies.id', '=', 'assembly_tenures.assembly_id')
        ->select('main_sessions.*','assemblies.name')
        ->orderBy('main_sessions.id')
        ->get();
        $spg = $allmainSessions->unique('sessionname');
        $allmainSessions = array_slice($spg->values()->all(),0,1000, true);

        $allRows = [];
        foreach($allmainSessions as $msession){            
            $sessions = DB::table('resolutions_passeds as ord')
            ->join('sessions', 'sessions.id', '=', 'ord.sessions_id')
            ->select('sessions.*','ord.id as resolutionid','ord.date as resolutiondate')
            ->where('sessions.main_sessions_id', $msession->id)
            ->get();
            $sess = array(
                'sessionname'=>$msession->sessionname,
                'assemblyname'=>$msession->name,
                'sessionid'=>$msession->id,
                'listofsessions'=>$sessions
            );  
            array_push($allRows,$sess);
        }
        // dd($allRows);
        return response()->json($allRows);
    }

    public function get_sessionsquestion() {
        $allmainSessions = DB::table('questions')  
        ->join('sessions', 'sessions.id', '=', 'questions.sessions_id')
        ->join('main_sessions', 'main_sessions.id', '=', 'sessions.main_sessions_id')
        ->join('assembly_tenures', 'assembly_tenures.id', '=', 'main_sessions.assembly_tenures_id')
        ->join('assemblies', 'assemblies.id', '=', 'assembly_tenures.assembly_id')
        ->select('main_sessions.*','assemblies.name')
        ->orderBy('main_sessions.id')
        ->get();
        $spg = $allmainSessions->unique('sessionname');
        $allmainSessions = array_slice($spg->values()->all(),0,1000, true);

        $allRows = [];
        foreach($allmainSessions as $msession){            
            $sessions = DB::table('questions as ord')
            ->join('sessions', 'sessions.id', '=', 'ord.sessions_id')
            ->select('sessions.*','ord.id as questionid', 'ord.date as questiondate')
            ->where('sessions.main_sessions_id', $msession->id)
            ->get();
            $sess = array(
                'sessionname'=>$msession->sessionname,
                'assemblyname'=>$msession->name,
                'sessionid'=>$msession->id,
                'listofsessions'=>$sessions
            );  
            array_push($allRows,$sess);
        }
        // dd($allRows);
        return response()->json($allRows);
    }

    public function get_pressrelease(){
        $allRows = DB::table('press_releases')
        ->orderBy('id', 'desc')
        ->take(5)
        ->get();
        // dd($allRows);
        return response()->json($allRows);
    }

    public function get_newsandactivities(){
        $allRows = DB::table('press_releases')
        ->orderBy('id', 'desc')
        ->where('page','News and Activities')
        ->where('image','<>','-')
        ->where('type','text')
        ->take(5)
        ->get();
        // dd($allRows);
        return response()->json($allRows);
    }

    // public function get_newsandactivitiesAll(){
    //     $allRows = DB::table('press_releases')
    //     ->orderBy('id', 'desc')
    //     ->where('page','News and Activities')
    //     ->where('image','<>','-')
    //     ->where('type','text')
    //     ->get();
    //     // dd($allRows);
    //     return response()->json($allRows);
    // }

    public function get_notificationGeneral(){
        $allRows = DB::table('notifications')
        ->orderBy('id', 'desc')
        ->take(3)
        ->select('notifications.subject','notifications.letterno','notifications.date','notifications.type')
        ->where('page', 'General')
        ->get();
        // dd($allRows);
        return response()->json($allRows);
    }

    public function get_notificationSessions(){
        $allRows = DB::table('notifications')
        ->orderBy('id', 'desc')
        ->take(3)
        ->select('notifications.subject','notifications.letterno','notifications.date','notifications.type')
        ->where('page', 'Sessions')
        ->get();
        // dd($allRows);
        return response()->json($allRows);
    }

    public function get_notificationMembers(){
        $allRows = DB::table('notifications')
        ->orderBy('id', 'desc')
        ->take(3)
        ->select('notifications.subject','notifications.letterno','notifications.date','notifications.type')
        
        ->where('page', 'Members')
        ->get();
        // dd($allRows);
        return response()->json($allRows);
    }

    public function get_notificationCommittees(){
        $allRows = DB::table('notifications')
        ->orderBy('id', 'desc')
        ->take(3)
        ->select('notifications.subject','notifications.letterno','notifications.date','notifications.type')
        ->where('page', 'Committees')
        ->get();
        // dd($allRows);
        return response()->json($allRows);
    }
}
