<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Models\Message;
use App\Models\MembersDirectory;

class MessageController extends Controller
{
    function __construct()
    {
         $this->middleware('permission:messages-list|messages-edit', ['only' => ['index','store']]);
         $this->middleware('permission:messages-edit', ['only' => ['edit','update']]);
     
    }

    function get_messages(){

        $allRows = DB::table('messages')
        ->join('members_directories', 'members_directories.id','messages.members_directories_id')  
        ->select('messages.*','members_directories.image','members_directories.name as membername')
        ->get();
        return response()->json($allRows);
        
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $singleRow = Message::find(1);
        $deputyRow = Message::find(2);
        $memberDirectories = MembersDirectory::all();
        return view('messages', compact('singleRow','deputyRow','memberDirectories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $request->validate([
            'members_directories_id' => 'required',
            'description' => 'required'
        ]);

        $table = new Message;
        $table->members_directories_id = $request->members_directories_id;
        $table->description = $request->description;
        $table->save();
        return redirect()->route('messages.index')->with(['success'=>'Data has been Saved successfully']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       
        $singleRow = Message::find($id);
        $memberDirectories = MembersDirectory::all();
        return view('messages', compact('singleRow','memberDirectories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'members_directories_id' => 'required',
        
        ]);

        if($request->description2){

            $table = Message::find($id);
            $table->members_directories_id = $request->members_directories_id;
            $table->description = $request->description2;
            $table->designation = $request->designation;

        }else{
            $table = Message::find($id);
            $table->members_directories_id = $request->members_directories_id;
            $table->description = $request->description;
            $table->designation = $request->designation;

        }

        $table->save();
        return redirect()->route('messages.index')->with(['success'=>'Data has been Updated successfully']);
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $singleRow = Message::find($id);
        $singleRow->delete();
        return redirect()->route('about.index')->with(['success'=>'Data has been Deleted successfully']);
    }
}
