<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\RoleOfAssembly;

class RoleOfAssemblyController extends Controller
{
    public function get_roleofassembly()
    {
        $allRows = RoleOfAssembly::all();
        return response()->json($allRows);
    }
     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $singleRow = RoleOfAssembly::find(1);
        return view('roleofassembly', compact('singleRow'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       
        $singleRow = RoleOfAssembly::find($id);
        return view('roleofassembly', compact('singleRow'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'heading' => 'required',
            'description' => 'required'
        ]);

        $table = RoleOfAssembly::find($id);
        $table->heading = $request->heading;
        $table->description = $request->description;
        $table->save();
        return redirect()->route('roleofassembly.index')->with(['success'=>'Data has been Updated successfully']);
        
    }
}
