<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\WorkingOfAssembly;

class WorkingOfAssemblyController extends Controller
{
    function __construct()
    {
         $this->middleware('permission:working-of-assembly-list|working-of-assembly-edit', ['only' => ['index','store']]);
         $this->middleware('permission:working-of-assembly-edit', ['only' => ['edit','update']]);
    }
    public function get_workingofassembly()
    {
        $allRows = WorkingOfAssembly::all();
        return response()->json($allRows);
    } 
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $singleRow = WorkingOfAssembly::find(1);
        return view('workingofassembly', compact('singleRow'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       
        $singleRow = WorkingOfAssembly::find($id);
        return view('workingofassembly', compact('singleRow'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'heading' => 'required',
            'description' => 'required'
        ]);

        $table = WorkingOfAssembly::find($id);
        $table->heading = $request->heading;
        $table->description = $request->description;
        $table->save();
        return redirect()->route('workingofassembly.index')->with(['success'=>'Data has been Updated successfully']);
        
    }

    
}
